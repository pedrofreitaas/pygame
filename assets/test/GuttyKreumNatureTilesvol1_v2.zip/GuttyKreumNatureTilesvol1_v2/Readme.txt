Greetings!

If you plan on using or editing these for your publicized works (you can also use these tiles for commercial works) please credit Gutty Kreum and include a link to https://twitter.com/GuttyKreum or https://guttykreum.tumblr.com/

Thank you and enjoy!